#include <iostream>

using namespace std;

class Order;
class OrderProcessing;
class CoffeeShop;

//////////assignment 3 codes//////////
class Beverage {
protected:
	string description = "Unknown Beverage";
public:
	double product_cost = 0;
	virtual string getDescription() = 0;
	virtual double cost() = 0;
	void add_description(string new_des) {
		description = description + ", " + new_des;
	};
	virtual ~Beverage() {/*cout << "Beverage distructed" << endl;*/ };
};

class Espresso : public Beverage {
public:
	Espresso() {
		description = "Espresso";
		product_cost = 1.99;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Espresso() { /*cout << "Espresso distructed" << endl;*/ };
};

class HouseBlend : public Beverage {
public:
	HouseBlend() {
		description = "House Blend Coffee";
		product_cost = 0.89;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~HouseBlend() { /*cout << "HouseBlend distructed" << endl;*/ };
};

class Decorator : public Beverage {
protected:
	Beverage* beverage;
public:
	~Decorator() { /* cout << "Decorator distructed" << endl; */ };
};

class Mocha : public Decorator {
public:
	Mocha(Beverage* t_beverage) {
		t_beverage->add_description("Mocha");
		description = t_beverage->getDescription();
		t_beverage->product_cost += 0.20;
		product_cost = t_beverage->product_cost;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Mocha() {/*cout << "Mocha distructed" << endl; */ };
};

class Whip : public Decorator {
public:
	Whip(Beverage* t_beverage) {
		t_beverage->add_description("Whip");
		description = t_beverage->getDescription();
		t_beverage->product_cost += 0.45;
		product_cost = t_beverage->product_cost;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Whip() { /*cout << "Whip distructed" << endl;*/ };
};

///////////////////////////////////////////////////

class Order {
private:
	//Order ID
	string orderID;
	string orderName;
	double orderPrice;
public:
	Order();
	Order(string id, string oname);
	Order(string id, Beverage* oname);
	~Order();
	string getOrderInfo() { return orderName; }
	string getOrderID() { return orderID; }
	double getOrderPrice() { return orderPrice; }
};

class OrderProcessing {
private:
	//List of pending in-dining orders
	int maxNumOrder; //Max number of in-dining order
	Order* orderQueue;	//A queue of orders
	int front, rear;	//The front and rear of the queue	
	//Total ordercount (Static)
	static int OrderCnt;


public:
	int addOrder(Order newOrder);
	int serveOrder();	//Serve the oldest order
	int getTotalOrderCnt() { return OrderCnt; }	//Return the total number of orders so far
	OrderProcessing(int maxOrder);
	friend istream& operator>>(istream &in, Order &t_o);
	~OrderProcessing();
};

class CoffeeShop {
private:
	int numOfTables; //The number of in-dining tables
	string name;
	OrderProcessing* myOrderProcessing;	//My order processing
public:
	//Check the number of in-dining tables
	CoffeeShop();	//Use Create a default number of table
	CoffeeShop(int numTable); //Take the number of tables
	CoffeeShop(int numTable, string shop_name);

	//Destructor
	~CoffeeShop();

	//Get OrderProcessingHandler
	OrderProcessing* getOrderProcessingHandler() { return myOrderProcessing; }
};

//Constructor
CoffeeShop::CoffeeShop() : numOfTables(10), name("")// Use Create a default number of table
{
	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::CoffeeShop(int numTable) : numOfTables(numTable), name("")
{
	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::CoffeeShop(int numTable, string shop_name) : numOfTables(numTable), name(shop_name) {

	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::~CoffeeShop() {
	//Deallocate the memory
	delete myOrderProcessing;
	//cout << "Destructur called : [" << "CoffeeShop" << "]" << endl;
}


//Initialize static member
int OrderProcessing::OrderCnt = 0;

//Constructor
OrderProcessing::OrderProcessing(int maxOrder) {
	//cout << "Order Processing class is created: Max Order Number [" << maxOrder << "]" << endl;
	maxNumOrder = maxOrder;
	front = rear = 0;
	orderQueue = new Order[maxOrder];
}

//Destructor
OrderProcessing::~OrderProcessing() {
	//Deallocate the memory
	delete[] orderQueue;
	//cout << "Destructur called : [" << "OrderProcessing" << "]" << endl;
}

//Implementation: https://www.geeksforgeeks.org/array-implementation-of-queue-simple/
//Add an order (Return 0: fail, Return 1: success)
int OrderProcessing::addOrder(Order newOrder) {
	if (maxNumOrder == rear) {
		cout << "Queue is full, ";
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 0;
	}
	else {
		OrderCnt++;		//Increase an order count
		orderQueue[rear] = newOrder;
		rear++;
		cout << "[" << newOrder.getOrderInfo() << "] is ordered by [" << newOrder.getOrderID() << "] ";
		cout << "with cost $" << newOrder.getOrderPrice();
		cout << " Total orders so far : " << getTotalOrderCnt() << endl;
		return 1;
	}
}

//Remove an order (delete an item from the front of the queue) (Return 0: fail, Return 1: success)
int OrderProcessing::serveOrder() {
	if (front == rear) {
		cout << "Queue is empty, ";
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 0;
	}
	else {
		//if queue is empty
		cout << "[" << orderQueue[front].getOrderInfo() << "] is served to [" << orderQueue[front].getOrderID() << "], ";
		for (int i = 0; i < rear - 1; i++) {
			orderQueue[i] = orderQueue[i + 1];
		}
		//decrement rear
		rear--;
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 1;
	}
}




Order::Order() :orderID("None"), orderName("") {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;
}
Order::Order(string id, string oname) : orderID(id), orderName(oname) {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;
}
Order::Order(string id, Beverage* oname) : orderID(id), orderName(oname->getDescription()), orderPrice(oname->cost()) {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;//
}
Order::~Order() {
	//cout << "Destructur called : [" << "Order" << "]" << endl;
}

istream& operator>>(istream& in, Order& t_o) {
	string name;
	int b_base;
    int b_deco;
	Beverage* beverage = new Espresso();

	///Get Order Name
	cout << "Enter your name for the order: ";
	in >> name;

	///Choose Beverage Base
	cout << "Select the Base Beverage: (1) Espresso ($1.99), (2) HouseBlend ($0.89) =>" << endl;
	in >> b_base;
	if (b_base == 1) beverage = new Espresso();
	else if (b_base == 2) beverage = new HouseBlend();

	///Choose Beverage Deco
	while (1) {
		cout << "Select the Decorators. After selecting all deco, press (3): (1) Mocha ($0.20), (2) Whipped Cream ($0.45), (3) Done = >" << endl;
		in >> b_deco;
		if (b_deco == 1) beverage = new Mocha(beverage);
		else if (b_deco == 2) beverage = new Whip(beverage);
		else if (b_deco == 3) break;
	}
	cout << "Finalizing the Order..." << endl;
	t_o = Order(name, beverage);
	return in;
};


int main() {

	CoffeeShop starbugs(3);
	Order t_o;
	do {
		cin >> t_o;
	} while (starbugs.getOrderProcessingHandler()->addOrder(t_o));
	starbugs.getOrderProcessingHandler()->serveOrder();
	starbugs.getOrderProcessingHandler()->serveOrder();
	starbugs.getOrderProcessingHandler()->serveOrder();


	return 0;
}