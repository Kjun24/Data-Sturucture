#include <iostream>
#include <vector>
#include <string.h>

using namespace std;

class Order;
class OrderProcessing;
class CoffeeShop;

//////////assignment 3 codes//////////
class Beverage {
protected:
	string description = "Unknown Beverage";
public:
	double product_cost = 0;
	virtual string getDescription() = 0;
	virtual double cost() = 0;
	void add_description(string new_des) {
		description = description + ", " + new_des;
	};
	virtual ~Beverage() {/*cout << "Beverage distructed" << endl;*/ };
};

class Espresso : public Beverage {
public:
	Espresso() {
		description = "Espresso";
		product_cost = 1.99;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Espresso() { /*cout << "Espresso distructed" << endl;*/ };
};

class HouseBlend : public Beverage {
public:
	HouseBlend() {
		description = "House Blend Coffee";
		product_cost = 0.89;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~HouseBlend() { /*cout << "HouseBlend distructed" << endl;*/ };
};

class Decorator : public Beverage {
protected:
	Beverage* beverage;
public:
	~Decorator() { /* cout << "Decorator distructed" << endl; */ };
};

class Mocha : public Decorator {
public:
	Mocha(Beverage* t_beverage) {
		t_beverage->add_description("Mocha");
		description = t_beverage->getDescription();
		t_beverage->product_cost += 0.20;
		product_cost = t_beverage->product_cost;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Mocha() {/*cout << "Mocha distructed" << endl; */ };
};

class Whip : public Decorator {
public:
	Whip(Beverage* t_beverage) {
		t_beverage->add_description("Whip");
		description = t_beverage->getDescription();
		t_beverage->product_cost += 0.45;
		product_cost = t_beverage->product_cost;
	};
	string getDescription() { return description; };
	double cost() { return product_cost; };
	~Whip() { /*cout << "Whip distructed" << endl;*/ };
};

///////////////////////////////////////////////////

class Order {
private:
	//Order ID
	string orderID;
	string orderName;
	double orderPrice;
public:
	Order();
	Order(string id, string oname);
	Order(string id, Beverage* oname);
	~Order();
	string getOrderInfo() { return orderName; }
	string getOrderID() { return orderID; }
	double getOrderPrice() { return orderPrice; }
};

class OrderProcessing {
private:
	int maxNumOrder; //Max number of in-dining order
	static int OrderCnt;
	vector<Order> orderQueue;

public:
	int addOrder(Order newOrder);
	int serveOrder();	//Serve the oldest order
	int getTotalOrderCnt() { return OrderCnt; }	//Return the total number of orders so far
	OrderProcessing(int maxOrder);
	~OrderProcessing();
};

class CoffeeShop {
private:
	int numOfTables; //The number of in-dining tables
	string name;
	OrderProcessing* myOrderProcessing;	//My order processing
public:
	//Check the number of in-dining tables
	CoffeeShop();	//Use Create a default number of table
	CoffeeShop(int numTable); //Take the number of tables
	CoffeeShop(int numTable, string shop_name);

	//Destructor
	~CoffeeShop();

	//Get OrderProcessingHandler
	OrderProcessing* getOrderProcessingHandler() { return myOrderProcessing; }
};

//Constructor
CoffeeShop::CoffeeShop() : numOfTables(10), name("")// Use Create a default number of table
{
	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::CoffeeShop(int numTable) : numOfTables(numTable), name("")
{
	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::CoffeeShop(int numTable, string shop_name) : numOfTables(numTable), name(shop_name) {

	myOrderProcessing = new OrderProcessing(numOfTables);
	//cout << "CoffeeShop: [" << name << "] is created (Table number: " << numOfTables << ")" << endl;
}

CoffeeShop::~CoffeeShop() {
	//Deallocate the memory
	delete myOrderProcessing;
	//cout << "Destructur called : [" << "CoffeeShop" << "]" << endl;
}


//Initialize static member
int OrderProcessing::OrderCnt = 0;

//Constructor
OrderProcessing::OrderProcessing(int maxOrder) {
	//cout << "Order Processing class is created: Max Order Number [" << maxOrder << "]" << endl;
	maxNumOrder = maxOrder;
}

//Destructor
OrderProcessing::~OrderProcessing() {
	//Deallocate the memory
	orderQueue.clear();
	orderQueue.shrink_to_fit();
	//cout << "Destructur called : [" << "OrderProcessing" << "]" << endl;
}

//Implementation: https://www.geeksforgeeks.org/array-implementation-of-queue-simple/
//Add an order (Return 0: fail, Return 1: success)
int OrderProcessing::addOrder(Order newOrder) {
	if (maxNumOrder == orderQueue.size()) {
		cout << "Queue is full, ";
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 0;
	}
	else {
		OrderCnt++;		//Increase an order count
		orderQueue.push_back(newOrder);
		cout << "[" << newOrder.getOrderInfo() << "] is ordered by [" << newOrder.getOrderID() << "] ";
		cout << "with cost $" << newOrder.getOrderPrice();
		cout << " Total orders so far : " << getTotalOrderCnt() << endl;
		return 1;
	}
}

//Remove an order (delete an item from the front of the queue) (Return 0: fail, Return 1: success)
int OrderProcessing::serveOrder() {
	if (orderQueue.empty()) {
		cout << "Queue is empty, ";
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 0;
	}
	else {
		//if queue is empty
		cout << "[" << orderQueue.front().getOrderInfo() << "] is served to [" << orderQueue.front().getOrderID() << "], ";
		orderQueue.erase(orderQueue.begin());
		//decrement rear
		cout << "Total orders so far : " << getTotalOrderCnt() << endl;
		return 1;
	}
}




Order::Order() :orderID("None"), orderName("") {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;
}
Order::Order(string id, string oname) : orderID(id), orderName(oname) {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;
}
Order::Order(string id, Beverage* oname) : orderID(id), orderName(oname->getDescription()), orderPrice(oname->cost()) {
	//cout << "An Order is created: Name[" << orderName << "]" << endl;//
}
Order::~Order() {
	//cout << "Destructur called : [" << "Order" << "]" << endl;
}


int main() {

	Beverage* beverage1;
	beverage1 = new Espresso(); //1.99
	beverage1 = new Mocha(beverage1); //0.20
	beverage1 = new Mocha(beverage1); //0.20
	cout << "Total cost: " << beverage1->cost() << endl;
	cout << beverage1->getDescription() << endl;

	Beverage* beverage2;
	beverage2 = new HouseBlend(); //0.89
	beverage2 = new Mocha(beverage2); //0.20
	beverage2 = new Whip(beverage2); //0.45
	cout << "Total cost: " << beverage2->cost() << endl;
	cout << beverage2->getDescription() << endl;

	CoffeeShop starbugs(5);
	Order o1("Alice", beverage1), o2("Bob", beverage2);
	starbugs.getOrderProcessingHandler()->addOrder(o1);
	starbugs.getOrderProcessingHandler()->addOrder(o2);
	starbugs.getOrderProcessingHandler()->serveOrder();
	starbugs.getOrderProcessingHandler()->serveOrder();
	starbugs.getOrderProcessingHandler()->serveOrder();
	return 0;

}